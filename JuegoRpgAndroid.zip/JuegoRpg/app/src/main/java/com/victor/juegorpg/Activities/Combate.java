package com.victor.juegorpg.Activities;

import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.victor.juegorpg.Activities.Creacion_Personaje;

import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.R;

public class Combate extends AppCompatActivity implements View.OnClickListener{

    //Declaración de objetos.
    public TextView texto_nombre_pj, texto_vida_pj, texto_vida_e;
    public ImageView imagen_pj, imagen_e;
    public Bundle bundle_pj, bundle_e;
    public Button boton_atacar, boton_objetos;

    //Declaración de variables.
    String vida_e;
    String vida_pj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combate);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_nombre_pj = (TextView) findViewById(R.id.texto_nombre_pj);
        texto_vida_pj = (TextView) findViewById(R.id.texto_vida_pj);
        imagen_pj = (ImageView) findViewById(R.id.imagen_pj);
        texto_vida_e = (TextView) findViewById(R.id.texto_vida_e);
        imagen_e = (ImageView) findViewById(R.id.imagen_e);
        boton_atacar = (Button) findViewById(R.id.boton_atacar);
        boton_objetos = (Button) findViewById(R.id.boton_objetos);

        //Pasamos el nombre escrito al personaje a su TextView.
        String nombre = getIntent().getStringExtra("nombre");
        texto_nombre_pj.setText(nombre);

        //Pasamos la vida del personaje a su TextView.
        vida_pj = getIntent().getStringExtra("vida");
        texto_vida_pj.setTextColor(Color.BLACK);
        texto_vida_pj.setText(vida_pj);

        //Pasamos la vida del enemigo a su TextView.
        vida_e = getIntent().getStringExtra("vida_enemigo");
        texto_vida_e.setTextColor(Color.BLACK);
        texto_vida_e.setText(vida_e);

        //Asignamos la imagen al personaje.
        bundle_pj = this.getIntent().getExtras();
        int pic_pj = bundle_pj.getInt("imagen_pj");
        imagen_pj.setImageResource(pic_pj);

        //Asignamos la imagen al enemigo.
        bundle_e = this.getIntent().getExtras();
        int pic_e = bundle_e.getInt("imagen_e");
        imagen_e.setImageResource(pic_e);


    }

    //Controlamos las acciones de los botones desde el método OnClick.
    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.boton_atacar:
                Task ataque = new Task();
                ataque.execute();

            break;

            case R.id.boton_objetos:

            break;

        }
    }

    private void tareaLarga() {
        try {
            Thread.sleep(1000);
        } catch(InterruptedException e) {}
    }

    private class Task extends AsyncTask<Void,Integer, Void>{

        @Override
        protected Void doInBackground(Void... voids) {

            int v = Creacion_Personaje.enemigo.getVida();

                v -= (Creacion_Personaje.pj.getAtk_fisico()*(100 - Creacion_Personaje.enemigo.getArmadura_fisica())/100);

            publishProgress(v);

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);

            int vida = values[0].intValue();

            texto_vida_e.setText(vida + "/" + Creacion_Personaje.enemigo.getVidaMax());

        }

    }


}




