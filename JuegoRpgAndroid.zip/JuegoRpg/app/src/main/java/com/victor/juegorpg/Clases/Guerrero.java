package com.victor.juegorpg.Clases;

import android.media.Image;

public class Guerrero extends Personaje{

    //Métodos constructores.
    public Guerrero(){
        this.vida = 1000;
        this.vidaMax=this.vida;
        this.atk_fisico = 200;
        this.atk_magico = 50;
        this.armadura_fisica = 50;
        this.armadura_magica = 0;
        this.pm = 50;
    }

    public Guerrero(int vida, int atk_fisico, int atk_magico, int armadura_fisica, int armadura_magica, int pm) {
        this.vida = vida;
        this.vidaMax=vida;
        this.atk_fisico = atk_fisico;
        this.atk_magico = atk_magico;
        this.armadura_fisica = armadura_fisica;
        this.armadura_magica = armadura_magica;
        this.pm = pm;
    }

}
