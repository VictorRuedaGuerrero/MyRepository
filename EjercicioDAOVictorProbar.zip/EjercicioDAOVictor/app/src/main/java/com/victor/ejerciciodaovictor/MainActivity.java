package com.victor.ejerciciodaovictor;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.victor.ejerciciodaovictor.entidad.Producto;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //Declaración de objetos.
    ImageView imagen_crear;
    public static ArrayList<Producto> listaProductos = new ArrayList<>();
    private RecyclerView mRecyclerView;
    public static AdapterDatos adapter;

    DatabaseReference bbdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //For para hacer que se vean los datos del producto.
        //Relación entre los elementos de la activity y la parte lógica del programa.
        imagen_crear = findViewById(R.id.imagen_crear);
        mRecyclerView = findViewById(R.id.recycler);

        //Creación adaptador e introducción del context y del ArrayList listaProductos por parámetros.
        adapter = new AdapterDatos(this, listaProductos);

        //Conexión del adaptador con nuestra RecyclerView.
        mRecyclerView.setAdapter(adapter);

        //Dar a nuestro RecyclerView un gestor de diseño predeterminado (LayoutManager).
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Inicialización del ArrayList para que se muestren los datos.


        //Llamadas al método onClick para realizar las acciones con los elementos indicados correctamente.
        imagen_crear.setOnClickListener(this);

    }

    //Método onClick para controlar las acciones de las imágenes (bóton de crear y botón de eliminar).
    @Override
    public void onClick(View v) {

        Intent i = new Intent(MainActivity.this, ActivityCreacion.class);
        startActivity(i);

    }

}

