package com.victor.ejerciciodaovictor;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.victor.ejerciciodaovictor.entidad.Producto;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos>{

    //Declaración de objetos:
    private final ArrayList<Producto> listaProductos;
    private LayoutInflater mInflater;

    public AdapterDatos(Context context, ArrayList<Producto> listaProductos) {
        mInflater = LayoutInflater.from(context);
        this.listaProductos = listaProductos;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View mItemView = mInflater.inflate(R.layout.item_list, viewGroup, false);
        return new ViewHolderDatos(mItemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.asignarDatos(listaProductos.get(i));

    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }


    class ViewHolderDatos extends RecyclerView.ViewHolder{

        public final TextView nombre_producto, id_producto, fecha;
        public final ImageView imagen_eliminar;
        final AdapterDatos mAdapter;

        public ViewHolderDatos(@NonNull View itemView, AdapterDatos adapter) {
            super(itemView);
            nombre_producto = itemView.findViewById(R.id.nombre_producto);
            id_producto = itemView.findViewById(R.id.id_producto);
            fecha = itemView.findViewById(R.id.fecha);
            imagen_eliminar = itemView.findViewById(R.id.imagen_eliminar);
            this.mAdapter = adapter;
        }

        public void asignarDatos(final Producto p){
            nombre_producto.setText(p.getNombre());
            id_producto.setText(p.getId_producto());
            fecha.setText(p.getFecha());
        }


    }
}
