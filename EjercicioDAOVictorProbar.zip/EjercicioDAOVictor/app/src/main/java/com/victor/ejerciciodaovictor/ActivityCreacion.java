package com.victor.ejerciciodaovictor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.victor.ejerciciodaovictor.dao.ProductoDAO;
import com.victor.ejerciciodaovictor.entidad.Producto;

public class ActivityCreacion extends AppCompatActivity implements View.OnClickListener {

    private EditText cre_nombreProducto, cre_idProducto, cre_fechaAlmacenamiento, cre_urlImagen, cre_descripcion;
    private Button boton_crear;
    private String nombreProducto, idProducto, fecha, descripcion, url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creacion);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        cre_nombreProducto = (EditText) findViewById(R.id.cre_nombreProducto);
        cre_idProducto = (EditText) findViewById(R.id.cre_idProducto);
        cre_fechaAlmacenamiento = (EditText) findViewById(R.id.cre_fechaAlmacenamiento);
        cre_urlImagen = (EditText) findViewById(R.id.cre_urlImagen);
        cre_descripcion = (EditText) findViewById(R.id.cre_descripcion);
        boton_crear = (Button) findViewById(R.id.boton_crear);

        boton_crear.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
       nombreProducto = cre_nombreProducto.getText().toString();
       idProducto = cre_idProducto.getText().toString();
       fecha = cre_fechaAlmacenamiento.getText().toString();
       descripcion = cre_descripcion.getText().toString();
       url = cre_urlImagen.getText().toString();
       añadirProducto();
       Intent i = new Intent(ActivityCreacion.this, MainActivity.class);
       startActivity(i);
    }

    /*Método para añadir los  valores Strings correspondientes al objeto producto  y le pasa esos valores al método crearProducto
    para realizar la insercción de los datos en la Base de Datos*/
    public void añadirProducto(){
        Producto producto = new Producto (idProducto, nombreProducto, fecha, descripcion, url);

        ProductoDAO datos = new ProductoDAO();
        datos.crearProducto(producto);
    }

}
