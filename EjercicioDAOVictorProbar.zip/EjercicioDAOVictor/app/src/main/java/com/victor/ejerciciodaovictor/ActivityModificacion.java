package com.victor.ejerciciodaovictor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.victor.ejerciciodaovictor.entidad.Producto;

public class ActivityModificacion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificacion);

        Bundle bundle =new Bundle();
        Producto p = (Producto) bundle.getSerializable("miProducto");
    }
}
