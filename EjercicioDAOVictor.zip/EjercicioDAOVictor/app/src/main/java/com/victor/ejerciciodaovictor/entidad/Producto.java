package com.victor.ejerciciodaovictor.entidad;

import java.util.Date;

public class Producto {

    private int id_producto;
    private String nombre;
    private String descripcion;
    private Date fecha_almacenamiento;
    private String url_imagen;

    public Producto(){
        super();
    }
    public Producto(int id_producto, String nombre, String descripcion, Date fecha_almacenamiento, String url_imagen) {
        super();
        this.id_producto = id_producto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fecha_almacenamiento = fecha_almacenamiento;
        this.url_imagen = url_imagen;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha_almacenamiento() {
        return fecha_almacenamiento;
    }

    public void setFecha_almacenamiento(Date fecha_almacenamiento) {
        this.fecha_almacenamiento = fecha_almacenamiento;
    }

    public String getUrl_imagen() {
        return url_imagen;
    }

    public void setUrl_imagen(String url_imagen) {
        this.url_imagen = url_imagen;
    }
}
