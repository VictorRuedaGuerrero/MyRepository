package com.victor.ejerciciodaovictor.idao;

public interface IProductoDAO {

    public void crearProducto();
    public void eliminarProducto();
    public void actualizarProudcto();
    public void LeerProducto();
}
