package com.victor.ejerciciodaovictor.dao;

import com.victor.ejerciciodaovictor.idao.IProductoDAO;

public class ProductoDAO implements IProductoDAO {

    @Override
    public void crearProducto() {

    }

    @Override
    public void eliminarProducto() {

    }

    @Override
    public void actualizarProudcto() {

    }

    @Override
    public void LeerProducto() {

    }
}
