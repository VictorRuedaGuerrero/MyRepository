package com.victor.ejerciciodaovictor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ArrayList<String> listDatos;
    RecyclerView recycler;
    ImageView imagen_crear, imagen_eliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        recycler = (RecyclerView) findViewById(R.id.recyclerId);
        imagen_crear = (ImageView) findViewById(R.id.imagen_crear);
        imagen_eliminar = (ImageView) findViewById(R.id.imagen_eliminar);

        recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        listDatos = new ArrayList<String>();

        for (int i=0; i<=2; i++) {
            listDatos.add("id#"+i+" ");
        }
        AdapterDatos adapter = new AdapterDatos(listDatos);
        recycler.setAdapter(adapter);

        //Llamadas al método onClick para realizar las acciones.
        imagen_crear.setOnClickListener(this);
    }

    //Método onClick para controlar las acciones de las imágenes (bóton de crear y botón de eliminar).
    @Override
    public void onClick(View v) {

        switch(v.getId()){

            case R.id.imagen_crear:
                Intent i = new Intent(MainActivity.this, ActivityCreacion.class);
                startActivity(i);
                break;

            case R.id.imagen_eliminar:
        }
    }
}

