package com.victor.ejerciciodaovictor;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {

    ArrayList<String> listDatos;

    //Método Constructor por parámetros de la clase AdapterDatos.
    public AdapterDatos(ArrayList<String> listDatos) {

        this.listDatos = listDatos;
    }

    //Método que enlaza nuestro adaptador con el archivo xml ---> item_list.xml.
    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list, viewGroup,false);
        return new ViewHolderDatos(view);
    }

    //Esta clase se encarga de establecer la comunicación entre nuestro adaptador y la clase "ViewHolderDatos".
    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {

        viewHolderDatos.asignarDatos(listDatos.get(i));
    }

    //Este método get nos devuelve el tamaño del ArrayList "listDatos" que hemos creado.
    @Override
    public int getItemCount() {

        return listDatos.size();
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView id_producto;
        private final Context context;

        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            id_producto = (TextView) itemView.findViewById(R.id.id_producto);
            context = itemView.getContext();
            itemView.setOnClickListener(this);
        }

        public void asignarDatos(String s) {
            id_producto.setText(s);
        }

        @Override
        public void onClick(View v) {
            Intent i = new Intent(context.getApplicationContext(),ActivityModificacion.class);
            context.startActivity(i);
        }
    }
}
