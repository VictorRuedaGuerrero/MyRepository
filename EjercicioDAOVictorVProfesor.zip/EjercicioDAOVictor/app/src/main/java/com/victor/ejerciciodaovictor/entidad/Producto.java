package com.victor.ejerciciodaovictor.entidad;

import java.util.Date;

public class Producto {

    private String id_producto;
    private String nombre;
    private String descripcion;
    private String fecha_almacenamiento;
    private String url_imagen;

    public Producto(){
        super();
    }

    public Producto(String id_producto, String nombre, String descripcion, String fecha_almacenamiento, String url_imagen) {
        super();
        this.id_producto = id_producto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fecha_almacenamiento = fecha_almacenamiento;
        this.url_imagen = url_imagen;
    }

    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha_almacenamiento() {
        return fecha_almacenamiento;
    }

    public void setFecha_almacenamiento(String fecha_almacenamiento) {
        this.fecha_almacenamiento = fecha_almacenamiento;
    }

    public String getUrl_imagen() {
        return url_imagen;
    }

    public void setUrl_imagen(String url_imagen) {
        this.url_imagen = url_imagen;
    }
}
