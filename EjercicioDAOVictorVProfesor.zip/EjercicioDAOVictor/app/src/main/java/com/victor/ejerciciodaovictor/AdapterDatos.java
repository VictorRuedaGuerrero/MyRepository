package com.victor.ejerciciodaovictor;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.victor.ejerciciodaovictor.entidad.Producto;

import java.util.ArrayList;
import java.util.List;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {

    private List<Producto> listDatos = new ArrayList<>();
    private LayoutInflater mInflater;

    //Método Constructor por parámetros de la clase AdapterDatos.
    public AdapterDatos(Context context, ArrayList<Producto> listDatos) {
        mInflater = LayoutInflater.from(context);
        this.listDatos = listDatos;
    }

    //Método que enlaza nuestro adaptador con el archivo xml ---> item_list.xml.
    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = mInflater.inflate(R.layout.item_list, viewGroup,false);
        return new ViewHolderDatos(view, this);
    }

    //Esta clase se encarga de establecer la comunicación entre nuestro adaptador y la clase "ViewHolderDatos".
    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        Producto mCurrent = listDatos.get(i);
        viewHolderDatos.itemView.setTag(mCurrent);
    }

    //Este método get nos devuelve el tamaño del ArrayList "listDatos" que hemos creado.
    @Override
    public int getItemCount() {

        return listDatos.size();
    }

    //Esta subclase se encarga de hacer la comunicación entre nuestro RecyclerView y nuestro item_list.
    public class ViewHolderDatos extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView id_producto, nombre_producto, fecha_almacenamiento;
        final AdapterDatos mAdapter;
        private final Context context;

        public ViewHolderDatos(@NonNull View itemView, AdapterDatos adapter) {
            super(itemView);
            id_producto = itemView.findViewById(R.id.id_producto);
            nombre_producto = itemView.findViewById(R.id.nombre_producto);
            fecha_almacenamiento = itemView.findViewById(R.id.fecha_almacenamiento);
            this.mAdapter = adapter;
            context = itemView.getContext();
            itemView.setOnClickListener(this);
        }

        public void asignarDatos(final Producto producto) {
            id_producto.setText(producto.getId_producto());
            nombre_producto.setText(producto.getNombre());
            fecha_almacenamiento.setText(producto.getFecha_almacenamiento());
        }

        /*Método Onclick que nos permite ir a la ActivityModificacion para modificar el producto que queramos
        pulsando sobre el item del producto en el Recycler.*/
        @Override
        public void onClick(View v) {
            Intent i = new Intent(context.getApplicationContext(),ActivityModificacion.class);
            context.startActivity(i);
        }
    }
}
