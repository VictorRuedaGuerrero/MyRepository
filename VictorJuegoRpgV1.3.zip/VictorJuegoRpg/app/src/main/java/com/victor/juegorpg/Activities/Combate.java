package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.victor.juegorpg.Activities.Creacion_Personaje;

import com.victor.juegorpg.Clases.Asesino;
import com.victor.juegorpg.Clases.Guerrero;
import com.victor.juegorpg.Clases.Mago;
import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.R;

public class Combate extends AppCompatActivity implements View.OnClickListener{

    //Declaración de objetos.
    public static TextView texto_nombre_pj, texto_vida_pj, texto_vida_e;
    public ImageView imagen_pj, imagen_e;
    public Button boton_atacar, boton_objetos, boton_tienda, boton_terminar;
    public static Button boton_pocion;
    public ScrollView scroll_objetos;
    public Toast toast_perdida;
    public Toast toast_ganada;
    public Toast toast_oro;
    public Intent i;
    public Personaje enemigo;

    //Declaración de variables.
    String vida_e;
    String vida_pj;
    static boolean turnos=true;
    static boolean terminar_task;
    static int oro = 0;
    String clases_enemigos;
    int cantidad_pociones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combate);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_nombre_pj = (TextView) findViewById(R.id.texto_nombre_pj);
        texto_vida_pj = (TextView) findViewById(R.id.texto_vida_pj);
        imagen_pj = (ImageView) findViewById(R.id.imagen_pj);
        texto_vida_e = (TextView) findViewById(R.id.texto_vida_e);
        imagen_e = (ImageView) findViewById(R.id.imagen_e);
        boton_atacar = (Button) findViewById(R.id.boton_atacar);
        boton_objetos = (Button) findViewById(R.id.boton_objetos);
        boton_tienda = (Button) findViewById(R.id.boton_tienda);
        boton_terminar = (Button) findViewById(R.id.boton_terminar);
        boton_pocion = (Button) findViewById(R.id.boton_pocion);


        //Pasamos el nombre escrito al personaje a su TextView.
        String nombre = getIntent().getStringExtra("nombre");
        texto_nombre_pj.setText(nombre);

        //Pasamos la vida del personaje a su TextView.
        vida_pj = Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax();
        texto_vida_pj.setTextColor(Color.BLACK);
        texto_vida_pj.setText(vida_pj);

        //Pasamos la vida del enemigo a su TextView.
        asignarNumClase();
        asignarClaseEnemigo();
        vida_e = enemigo.getVida() + " / " + enemigo.getVidaMax();
        texto_vida_e.setTextColor(Color.BLACK);
        texto_vida_e.setText(vida_e);

        terminar_task = false;

        //Asignamos la imagen del personaje al ImageView correspondiente que representa al personaje según su clase
        switch (Creacion_Personaje.pj.getClass().getSimpleName()){
            case "Guerrero":
                imagen_pj.setImageResource(R.drawable.guerrero);
                break;
            case "Asesino":
                imagen_pj.setImageResource(R.drawable.asesino);
                break;
            case "Mago":
                imagen_pj.setImageResource(R.drawable.mago);
                break;
            default:
                imagen_pj.setImageResource(R.drawable.ic_launcher_foreground);
                break;
        }


        //Asignamos la imagen del enemigo al ImageView correspondiente que representa al personaje según su clase
        switch (enemigo.getClass().getSimpleName()){
            case "Guerrero":
                imagen_e.setImageResource(R.drawable.guerrero);
                break;
            case "Asesino":
                imagen_e.setImageResource(R.drawable.asesino);
                break;
            case "Mago":
                imagen_e.setImageResource(R.drawable.mago);
                break;
            default:
                imagen_e.setImageResource(R.drawable.ic_launcher_foreground);
                break;
        }
    }

    //Método para asignar un String clase aleatorio al enemigo.
    public void asignarNumClase(){

        int numero = (int)(Math.random()*3)+1;

        switch(numero){

            case 1:
                clases_enemigos = "Guerrero";
                break;

            case 2:
                clases_enemigos = "Asesino";
                break;

            case 3:
                clases_enemigos = "Mago";
                break;
        }

    }

    //Método para asignar la clase al enemigo (con la ayuda del método "asignarNumClase" se escogerá de manera aleatoria).
    public void asignarClaseEnemigo(){

        switch (clases_enemigos){
            case "Guerrero":
                enemigo = new Guerrero();
                break;

            case "Asesino":
                enemigo = new Asesino();
                break;

            case "Mago":
                enemigo = new Mago();
                break;

            default:
                enemigo = new Guerrero();
                break;
        }

    }

    //Método para desactivar botones.
    public void desactivarBoton(){
        boton_atacar.setEnabled(false);
        boton_objetos.setEnabled(false);
    }

    //Método para activar botones.
    public void activarBoton(){
        boton_atacar.setEnabled(true);
        boton_objetos.setEnabled(true);
    }

    //Método para volver invisibles los botones.
    public void botonInvisible(){
        boton_atacar.setVisibility(View.INVISIBLE);
        boton_objetos.setVisibility(View.INVISIBLE);
    }

    //Método OnClick desde el que controlamos las acciones de los botones.
    @Override
    public void onClick(View v) {
        Task ataque = new Task();
        Task ataqueEnemigo = new Task();

        switch (v.getId()){

            case R.id.boton_atacar:
                desactivarBoton();

                ataque.execute();

                ataqueEnemigo.execute();
                boton_pocion.setVisibility(View.INVISIBLE);
                break;

            case R.id.boton_objetos:
                boton_pocion.setVisibility(View.VISIBLE);
                break;

            case R.id.boton_pocion:
                boton_pocion.setVisibility(View.INVISIBLE);
                break;

            case R.id.boton_tienda:
                i = new Intent(Combate.this, Tienda.class);
                startActivity(i);
                finish();
                break;

            case R.id.boton_terminar:
                i = new Intent(Combate.this, Menu_Juego.class);
                startActivity(i);
                finish();
                break;
        }

    }

    //Clase Asynctask que controla los hilos para realizar el ataque de manera correcta, tanto del enemigo como del personaje.
    class Task extends AsyncTask<Void,Integer,Void> {

        public Task() {
        }

        @Override
        protected Void doInBackground(Void... voids) {

            int vidaQueDisminuyeDe10en10 = -1;

            if (turnos == true) {
                int vidaFinalDelEnemigo = enemigo.getVida() - (Creacion_Personaje.pj.getAtk_fisico() * (100 - enemigo.getArmadura_fisica()) / 100);

                vidaQueDisminuyeDe10en10 = enemigo.getVida();

                //Mientras que la vida real del enemigo sea mayor que la que tendrá al final del combate la disminuimos y llamamos a Sleep para publicar el valor momentáneo de la vida
                // en la GUI (hilo principal).
                while (enemigo.getVida() > vidaFinalDelEnemigo && terminar_task == false) {
                    vidaQueDisminuyeDe10en10 = vidaQueDisminuyeDe10en10 - 10;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {}

                    enemigo.setVida(vidaQueDisminuyeDe10en10);
                    publishProgress(vidaQueDisminuyeDe10en10);

                    if (enemigo.getVida() <= 0) {
                        terminar_task = true;
                        break;
                    }
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {}

                turnos = false;

            } else {
                int vidaFinalDelPersonaje = Creacion_Personaje.pj.getVida() - (enemigo.getAtk_fisico() * (100 - Creacion_Personaje.pj.getArmadura_fisica()) / 100);

                vidaQueDisminuyeDe10en10 = Creacion_Personaje.pj.getVida();

                //Mientras que la vida real del enemigo sea mayor que la que tendrá al final del combate la disminuimos y llamamos a Sleep para publicar el valor momentáneo de la vida
                // en la GUI (hilo principal).
                while (Creacion_Personaje.pj.getVida() > vidaFinalDelPersonaje && terminar_task == false) {
                    vidaQueDisminuyeDe10en10 = vidaQueDisminuyeDe10en10 - 10;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                    }

                    Creacion_Personaje.pj.setVida(vidaQueDisminuyeDe10en10);
                    publishProgress(vidaQueDisminuyeDe10en10);

                    if (Creacion_Personaje.pj.getVida() <= 0) {
                        terminar_task = true;
                        break;
                    }
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {}

                turnos = true;
            }

            return null;
        }

            @Override
            protected void onProgressUpdate(Integer... values) {

                if (turnos == true) {
                    texto_vida_e.setText(enemigo.getVida() + " / " + enemigo.getVidaMax());
                } else {
                    texto_vida_pj.setText(Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax());
                }

                terminar();

            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                if (turnos == false)
                    activarBoton();

            }

            //Método para terminar el combate y que muestre el botón para ir a la tienda.
            // Además, mostrará un mensaje de tipo Toast según si has ganado o perdido.
            public void terminar() {

                if (enemigo.getVida() <= 0) {
                    oro = oro + 100;
                    toast_ganada = Toast.makeText(getApplicationContext(), "ERES UN CAMPEON!!, HAS GANADO: " + oro + " Oros.", Toast.LENGTH_LONG);
                    toast_ganada.show();
                    botonInvisible();
                    boton_tienda.setVisibility(View.VISIBLE);
                }

                if (Creacion_Personaje.pj.getVida() <= 0) {
                    toast_perdida = Toast.makeText(getApplicationContext(), "GAME OVER", Toast.LENGTH_LONG);
                    toast_perdida.show();
                    botonInvisible();
                    boton_tienda.setVisibility(View.INVISIBLE);
                    boton_terminar.setVisibility(View.VISIBLE);
                }

            }

        }

    }






