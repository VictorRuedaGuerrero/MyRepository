package com.victor.juegorpg.Objetos;

import com.victor.juegorpg.Activities.Combate;
import com.victor.juegorpg.Activities.Creacion_Personaje;

public class Objetos {

    //Declaración de variables.
    int cura=0;
    int aumento_vidaMax=0;
    int aumento_armadura_fisica=0;
    int aumento_ataque_fisico=0;

    //Métodos constructores.
    public Objetos(String eleccion){
        switch (eleccion){
            case "pocion_curativa":
                cura=300;
                break;
        }

    }

    //Método de la poción curativa.
    public void usarObjeto(String eleccion){
        switch (eleccion){
            case "pocion_curativa":
                Creacion_Personaje.pj.setVida(Creacion_Personaje.pj.getVida() + cura);
                Combate.texto_vida_e.setText(Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax());
                break;
        }
    }

    //Getters and Setters.
    public int getCura() {
        return cura;
    }

    public void setCura(int cura) {
        this.cura = cura;
    }

    public int getAumento_vidaMax() {
        return aumento_vidaMax;
    }

    public void setAumento_vidaMax(int aumento_vidaMax) {
        this.aumento_vidaMax = aumento_vidaMax;
    }

    public int getAumento_armadura_fisica() {
        return aumento_armadura_fisica;
    }

    public void setAumento_armadura_fisica(int aumento_armadura_fisica) {
        this.aumento_armadura_fisica = aumento_armadura_fisica;
    }

    public int getAumento_ataque_fisico() {
        return aumento_ataque_fisico;
    }

    public void setAumento_ataque_fisico(int aumento_ataque_fisico) {
        this.aumento_ataque_fisico = aumento_ataque_fisico;
    }
}
