package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.victor.juegorpg.R;

public class Tienda extends AppCompatActivity implements View.OnClickListener {

    //Declaración de objetos.
    public TextView texto_oro;
    public Button boton_compar_pocion_menor;
    Intent i;

    //Declaración de variables.
    static int cantidad_pocion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tienda);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_oro = (TextView) findViewById(R.id.texto_oro);
        boton_compar_pocion_menor = (Button) findViewById(R.id.boton_comprar_pocion_menor);

        //Muestra el oro en el elemento TextView "texto_oro"
        texto_oro.setText("Oro: " + Combate.oro);
    }

    //Método OnClick desde el que controlamos las acciones de los botones.
    @Override
    public void onClick(View v) {

        int valor_objeto;

        switch(v.getId()){

            case R.id.boton_comprar_pocion_menor:
                valor_objeto = 50;
                restaOro(valor_objeto);
                cantidad_pocion++;

            break;

            case R.id.boton_listo:
                i = new Intent (Tienda.this, Combate.class);
                startActivity(i);
            break;
        }

        texto_oro.setText("Oro: " + Combate.oro);

    }

    /*Método que resta el oro según el valor del objeto, pasado por parámetros. Además, controla si tienes menos cantidad
    que lo que vale el objeto, no te deja comprar más ese objeto.*/
    public void restaOro(int valor_objeto){

        Combate.oro -= valor_objeto;

        if(Combate.oro < 50){
            Combate.oro = 0;
            boton_compar_pocion_menor.setEnabled(false);
        }
    }



}
