package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.victor.juegorpg.Clases.Asesino;
import com.victor.juegorpg.Clases.Guerrero;
import com.victor.juegorpg.Clases.Mago;
import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.R;

public class Creacion_Personaje extends AppCompatActivity {

    //Declaración de objetos.
    private Spinner spinner1;
    private EditText seleccion_nombre;
    private Bundle bundle_pj = new Bundle();
    private Bundle bundle_e = new Bundle();
    public static Personaje pj;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creacion_personaje);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        seleccion_nombre = findViewById(R.id.seleccion_nombre);
        spinner1 = (Spinner)findViewById(R.id.spinner);


        //Creación y asignación de los valores al elemento Spinner.
        String [] opciones = {"Guerrero", "Asesino", "Mago"};

        ArrayAdapter <String> adapter = new ArrayAdapter <String>(this, android.R.layout.simple_spinner_dropdown_item, opciones);
        spinner1.setAdapter(adapter);
    }

    //Método para el botón confirmar para el nombre.
    public void crear(View view){
        i = new Intent(this, Combate.class);
        i.putExtra("nombre", seleccion_nombre.getText().toString());

        String clases = spinner1.getSelectedItem().toString();

        switch (clases){
            case "Guerrero":
                pj = new Guerrero();
                break;

            case "Asesino":
                pj = new Asesino();
                break;

            case "Mago":
                pj = new Mago();
                break;

            default:
                pj = new Guerrero();
                break;
        }
        startActivity(i);

    }
}
