package com.victor.juegorpg.Activities;

import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.victor.juegorpg.Activities.Creacion_Personaje;

import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.R;

public class Combate extends AppCompatActivity implements View.OnClickListener{

    //Declaración de objetos.
    public TextView texto_nombre_pj, texto_vida_pj, texto_vida_e;
    public ImageView imagen_pj, imagen_e;
    public Bundle bundle_pj, bundle_e;
    public Button boton_atacar, boton_objetos;

    //Declaración de variables.
    String vida_e;
    String vida_pj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combate);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_nombre_pj = (TextView) findViewById(R.id.texto_nombre_pj);
        texto_vida_pj = (TextView) findViewById(R.id.texto_vida_pj);
        imagen_pj = (ImageView) findViewById(R.id.imagen_pj);
        texto_vida_e = (TextView) findViewById(R.id.texto_vida_e);
        imagen_e = (ImageView) findViewById(R.id.imagen_e);
        boton_atacar = (Button) findViewById(R.id.boton_atacar);
        boton_objetos = (Button) findViewById(R.id.boton_objetos);

        //Pasamos el nombre escrito al personaje a su TextView.
        String nombre = getIntent().getStringExtra("nombre");
        texto_nombre_pj.setText(nombre);

        //Pasamos la vida del personaje a su TextView.
        vida_pj = Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax();
        texto_vida_pj.setTextColor(Color.BLACK);
        texto_vida_pj.setText(vida_pj);

        //Pasamos la vida del enemigo a su TextView.
        vida_e = Creacion_Personaje.enemigo.getVida() + " / " + Creacion_Personaje.enemigo.getVidaMax();
        texto_vida_e.setTextColor(Color.BLACK);
        texto_vida_e.setText(vida_e);

        //Con el método getClass podemos obtener la clase del objeto que asignamos a pj, y con getSimpleName lo acotamos para obtener como String el nombre simple de la clase, es decir
        //obviando el paquete en el que se encuentra
        //************************************************************************************************************************************************
        //************************************************************************************************************************************************
        //************************************************************************************************************************************************
        //ESTO TE LO HE PUESTO AQUÍ ÚNICAMENTE PARA QUE VEAS LA CLASE QUE SE LE ASIGNA AL OBJETO pj Y CÓMO CAMBIA CADA VEZ SEGÚN LA SELECCIÓN DEL SPINNER.
        System.out.println(Creacion_Personaje.pj.getClass().getSimpleName());
        //************************************************************************************************************************************************
        //************************************************************************************************************************************************
        //************************************************************************************************************************************************

        //Asignamos la imagen al ImageView que representa al personaje según su clase
        switch (Creacion_Personaje.pj.getClass().getSimpleName()){
            case "Guerrero":
                imagen_pj.setImageResource(R.drawable.guerrero);
                break;
            case "Asesino":
                imagen_pj.setImageResource(R.drawable.asesino);
                break;
            case "Mago":
                imagen_pj.setImageResource(R.drawable.mago);
                break;
            default:
                imagen_pj.setImageResource(R.drawable.ic_launcher_foreground);
                break;
        }


        //Asignamos la imagen al ImageView que representa al personaje según su clase
        switch (Creacion_Personaje.enemigo.getClass().getSimpleName()){
            case "Guerrero":
                imagen_e.setImageResource(R.drawable.guerrero);
                break;
            case "Asesino":
                imagen_e.setImageResource(R.drawable.asesino);
                break;
            case "Mago":
                imagen_e.setImageResource(R.drawable.mago);
                break;
            default:
                imagen_e.setImageResource(R.drawable.ic_launcher_foreground);
                break;
        }
    }

    //Controlamos las acciones de los botones desde el método OnClick.
    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.boton_atacar:
                Task ataque = new Task();
                ataque.execute();

            break;

            case R.id.boton_objetos:

            break;

        }
    }



    private class Task extends AsyncTask<Void,Integer, Void>{

        @Override
        protected Void doInBackground(Void... voids) {

            int vidaQueDisminuyeDe10en10=-1;

            //Esta variable contiene la vida que le quedará al enemigo después del ataque.
            int vidaFinalDelEnemigo = Creacion_Personaje.enemigo.getVida() - Creacion_Personaje.pj.getAtk_fisico();

            /*
            * En este bucle vamos a ir disminuyendo la vida del enemigo "poco a poco". Para dar el efecto de disminuirlo poco a poco vamos a realizar una llamada al método sleep
            * de la clase Thread. Con esto conseguiremos actualizar la GUI "poco a poco".
            * */


            vidaQueDisminuyeDe10en10 = Creacion_Personaje.enemigo.getVida();

            //Mientras que la vida real del enemigo sea mayor que la que tendrá al final del combate la disminuimos y llamamos a Sleep para publicar el valor momentáneo de la vida
            // en la GUI (hilo principal). Recuerda que la interfaz gráfica sólo se puede modificar desde el hilo principal. Por eso necesitamos hacer una llamada al método
            // publishProgress() que a su vez ejecuta el código de onProgressUpdate() el cuál sí que se ejecuta en el hilo principal (es un método "especial")
            while(Creacion_Personaje.enemigo.getVida() > vidaFinalDelEnemigo){
                vidaQueDisminuyeDe10en10 = vidaQueDisminuyeDe10en10 - 10;
                try {
                    Thread.sleep(100);
                } catch(InterruptedException e) {}

                Creacion_Personaje.enemigo.setVida(vidaQueDisminuyeDe10en10);
                publishProgress(vidaQueDisminuyeDe10en10);

            }


                //v -= (Creacion_Personaje.pj.getAtk_fisico()*(100 - Creacion_Personaje.enemigo.getArmadura_fisica())/100);


            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);

            int vida = values[0].intValue();

            texto_vida_e.setText(vida + "/" + Creacion_Personaje.enemigo.getVidaMax());

        }

    }


}




