package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.victor.juegorpg.Clases.Asesino;
import com.victor.juegorpg.Clases.Guerrero;
import com.victor.juegorpg.Clases.Mago;
import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.R;

public class Creacion_Personaje extends AppCompatActivity {

    //Declaración de objetos.
    private Spinner spinner1;
    private EditText seleccion_nombre;
    private Bundle bundle_pj = new Bundle();
    private Bundle bundle_e = new Bundle();
    public static Personaje pj;
    public static Personaje enemigo;
    Intent i;

    String clases_enemigos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creacion_personaje);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        seleccion_nombre = findViewById(R.id.seleccion_nombre);
        spinner1 = (Spinner)findViewById(R.id.spinner);


        //Creación y asignación de los valores al elemento Spinner.
        String [] opciones = {"Guerrero", "Asesino", "Mago"};

        ArrayAdapter <String> adapter = new ArrayAdapter <String>(this, android.R.layout.simple_spinner_dropdown_item, opciones);
        spinner1.setAdapter(adapter);
    }

    //Método para el botón confirmar para el nombre.
    public void crear(View view){
        i = new Intent(this, Combate.class);
        i.putExtra("nombre", seleccion_nombre.getText().toString());

        String clases = spinner1.getSelectedItem().toString();

        switch (clases){
            case "Guerrero":
                pj = new Guerrero();
                break;

            case "Asesino":
                pj = new Asesino();
                break;

            case "Mago":
                pj = new Mago();
                break;

            default:
                pj = new Guerrero();
                break;
        }

        asignarNumClase();
        asignarClaseEnemigo();
        startActivity(i);
    }


    //Método para asignar un String clase aleatorio al enemigo.
    public void asignarNumClase(){

        int numero = (int)(Math.random()*3)+1;

        switch(numero){

            case 1:
                clases_enemigos = "Guerrero";
                break;

            case 2:
                clases_enemigos = "Asesino";
                break;

            case 3:
                clases_enemigos = "Mago";
                break;
        }

    }


    //Método para asignar la clase al enemigo (con la ayuda del método "asignarNumClase" se escogerá de manera aleatoria).
    public void asignarClaseEnemigo(){

        switch (clases_enemigos){
            case "Guerrero":
                enemigo = new Guerrero();
                break;

            case "Asesino":
                enemigo = new Asesino();
                break;

            case "Mago":
                enemigo = new Mago();
                break;

            default:
                enemigo = new Guerrero();
                break;
        }
    }
}
