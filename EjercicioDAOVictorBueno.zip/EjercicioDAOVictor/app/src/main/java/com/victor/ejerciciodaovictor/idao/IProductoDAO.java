package com.victor.ejerciciodaovictor.idao;

import com.victor.ejerciciodaovictor.entidad.Producto;

public interface IProductoDAO {

    public void crearProducto(Producto producto);
    public void eliminarProducto();
    public void actualizarProducto();
    public void leerProducto();
}
