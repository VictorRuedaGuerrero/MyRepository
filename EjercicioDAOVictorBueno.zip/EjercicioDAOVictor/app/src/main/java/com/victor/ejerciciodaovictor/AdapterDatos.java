package com.victor.ejerciciodaovictor;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.victor.ejerciciodaovictor.entidad.Producto;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos>{

    //Declaración de objetos:
    private final ArrayList<Producto> listaProductos;
    private LayoutInflater mInflater;

    public AdapterDatos(Context context, ArrayList<Producto> listaProductos) {
        mInflater = LayoutInflater.from(context);
        this.listaProductos = listaProductos;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View mItemView = mInflater.inflate(R.layout.item_list, viewGroup, false);
        return new ViewHolderDatos(mItemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.asignarDatos(listaProductos.get(i));

    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }


    class ViewHolderDatos extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView nombre_producto, id_producto, fecha;
        public ImageView imagen_eliminar;
        final AdapterDatos mAdapter;
        private final Context context;

        public ViewHolderDatos(@NonNull View itemView, AdapterDatos adapter) {
            super(itemView);
            nombre_producto = itemView.findViewById(R.id.nombre_producto);
            id_producto = itemView.findViewById(R.id.id_producto);
            fecha = itemView.findViewById(R.id.fecha);
            imagen_eliminar = itemView.findViewById(R.id.imagen_eliminar);
            this.mAdapter = adapter;
            context = itemView.getContext();
            itemView.setOnClickListener(this);
        }

        public void asignarDatos(final Producto p){
            nombre_producto.setText(p.getNombre());
            id_producto.setText(p.getId_producto());
            fecha.setText(p.getFecha());
        }

        /*Método Onclick que nos permite ir a la ActivityModificacion para modificar el producto que queramos
        pulsando sobre el item del producto en el Recycler.*/
        @Override
        public void onClick(View v) {
            Intent i = new Intent(context.getApplicationContext(),ActivityModificacion.class);
            context.startActivity(i);
        }

    }
}
