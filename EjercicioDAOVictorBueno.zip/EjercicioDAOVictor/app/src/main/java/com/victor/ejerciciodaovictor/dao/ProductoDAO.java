package com.victor.ejerciciodaovictor.dao;

import android.support.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.victor.ejerciciodaovictor.AdapterDatos;
import com.victor.ejerciciodaovictor.MainActivity;
import com.victor.ejerciciodaovictor.entidad.Producto;
import com.victor.ejerciciodaovictor.idao.IProductoDAO;

import java.util.ArrayList;

public class ProductoDAO implements IProductoDAO {

    //Creación de objetos.
    DatabaseReference databaseReference;

    /*Método para referenciar a nuestra base de datos y añadir el nuevo producto que queremos insertar,
    es decir, crear nuestro producto.*/
    @Override
    public void crearProducto(Producto producto) {
        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Productos").child(producto.getId_producto()).setValue(producto);
    }

    @Override
    public void eliminarProducto() {

    }

    @Override
    public void actualizarProducto() {

    }

    @Override
    public void leerProducto() {

        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Productos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot productoSnapShot: dataSnapshot.getChildren()){
                    Producto p = productoSnapShot.getValue(Producto.class);
                    MainActivity.listaProductos.add(p);
                }

                MainActivity.adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
