package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.victor.juegorpg.R;

public class Tienda extends AppCompatActivity implements View.OnClickListener {

    //Declaración de objetos.
    public TextView texto_oro;
    public Button boton_compar_pocion_menor;
    public Intent i;

    //Declaración de variables.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tienda);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_oro = (TextView) findViewById(R.id.texto_oro);
        boton_compar_pocion_menor = (Button) findViewById(R.id.boton_comprar_pocion_menor);

        //Muestra el oro en el elemento TextView "texto_oro"
        texto_oro.setText("Oro: " + Combate.oro);
    }

    //Método OnClick desde el que controlamos las acciones de los botones.
    @Override
    public void onClick(View v) {

        int valor_objeto;

        switch(v.getId()){

            case R.id.boton_comprar_pocion_menor:
                valor_objeto = 50;
                Combate.oro -= valor_objeto;

                if(Combate.oro <= 0){
                    Combate.oro = 0;
                    boton_compar_pocion_menor.setEnabled(false);
                }
            break;

            case R.id.boton_listo:

            break;
        }

        texto_oro.setText("Oro: " + Combate.oro);
    }
}
