package juegorpg;

import Pantalla.*;
import java.awt.Color;


public class JuegoRpg {
    
    //Declaración de objetos.
    public static PantallaInicio inicio;
    public static MenuJuego menu;
    public static CreacionPj creacion;
    public static Combate combate;
    public static Personaje prota;
    public static Personaje enemigo;
    public static boolean activado = false;
    public static boolean comienza = false;
    
    public static void main(String[] args) throws InterruptedException {
       
        inicio = new PantallaInicio();
        
        //Muestro Pantalla de Inicio.
        inicio.setVisible(true);
        inicio.setLocationRelativeTo(null);
        inicio.setResizable(false);
        
        //Llamada al método turno.
        turno();
    }
    
    //método que controla los turnos.
    public static void turno() throws InterruptedException{
        
        //Bucle que controla la parada del método hasta que comience.
        while(comienza==false){
            System.out.println("");

        }
           
        while(prota.getVida() > 0 || enemigo.getVida() > 0){
            while(activado==false){
                System.out.println("");

            }
            turnoProta();
            Thread.sleep(300);
            turnoEnemigo();
            activarBotones();
            activado=false;
        }
    }
    
    //Método para controlar el turno del prota.
    public static void turnoProta() throws InterruptedException{
        
        int a=enemigo.getVida();

        combate.getTextoVidaE().setForeground(Color.red);
        for (int i = 0; i < (prota.getAtk_fisico()*(100 - enemigo.getArmadura_fisica())/100); i++) {
            a--;
            combate.getTextoVidaE().setText((a) +"/"+ enemigo.getVidaMax());
            Thread.sleep(10);

        }
        combate.getTextoVidaE().setForeground(Color.BLACK);
        enemigo.setVida(a);
        combate.getTextoVidaE().setText(enemigo.getVida() +"/"+ enemigo.getVidaMax());
    }
    
    //Método para controlar el turno del enemigo.
    public static void turnoEnemigo() throws InterruptedException{
        
        int a=prota.getVida();

        combate.getTextoVidaPj().setForeground(Color.red);
        for (int i = 0; i < (enemigo.getAtk_fisico()*(100 - prota.getArmadura_fisica())/100); i++) {
            a--;
            combate.getTextoVidaPj().setText((a) +"/"+ prota.getVidaMax());
            Thread.sleep(10);

        }
        combate.getTextoVidaPj().setForeground(Color.BLACK);
        prota.setVida(a);
        combate.getTextoVidaPj().setText(prota.getVida() +"/"+ prota.getVidaMax());
    }
    
    //Método para desactivar botones.
    public static void desactivarBotones(){
        
        combate.getAtacarB().setEnabled(false);
        combate.getObjetosB().setEnabled(false);
        combate.getHabilidadesB().setEnabled(false);   
    }
    
    //Método para activar botones.
    public static void activarBotones(){
        
        combate.getAtacarB().setEnabled(true);
        combate.getObjetosB().setEnabled(true);
        combate.getHabilidadesB().setEnabled(true);   
    }
    
}
