package juegorpg;

import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Asesino extends Personaje{
    
        public ImageIcon imagen;
    
    //Métodos constructores.
    public Asesino(String nombre){
        this.nombre = nombre;
        this.vida = 600;
        this.vidaMax=this.vida;
        this.atk_fisico = 300;
        this.atk_magico = 50;
        this.armadura_fisica = 50;
        this.armadura_magica = 0;
        this.pm = 50;
    }
    
    public Asesino(String nombre, int vida, int atk_fisico, int atk_magico, int armadura_fisica, int armadura_magica, int pm) {
        this.nombre = nombre;
        this.vida = vida;
        this.vidaMax=vida;
        this.atk_fisico = atk_fisico;
        this.atk_magico = atk_magico;
        this.armadura_fisica = armadura_fisica;
        this.armadura_magica = armadura_magica;
        this.pm = pm;
    }   
    
    //Método para asignar la imagen.
    public void asignarImagenPj(){
        imagen = new ImageIcon (this.getClass().getResource("/img/Asesino.png"));
        Icon icono = new ImageIcon(imagen.getImage().getScaledInstance(JuegoRpg.combate.getImagenPj().getWidth(), JuegoRpg.combate.getImagenPj().getHeight(), Image.SCALE_DEFAULT));
        JuegoRpg.combate.getImagenPj().setIcon(icono);
    }
    
    //Método para asignar la imagen del enemigo.
    public void asignarImagenE(){
        imagen = new ImageIcon (this.getClass().getResource("/img/Asesino.png"));
        Icon icono = new ImageIcon(imagen.getImage().getScaledInstance(JuegoRpg.combate.getImagenE().getWidth(), JuegoRpg.combate.getImagenE().getHeight(), Image.SCALE_DEFAULT));
        JuegoRpg.combate.getImagenE().setIcon(icono);
    }
    
}
