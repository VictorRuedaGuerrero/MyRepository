package juegorpg;

import javax.swing.ImageIcon;
import static juegorpg.JuegoRpg.creacion;

public abstract class Personaje {
    
    ImageIcon imagen;
    
    //Declaración de variables.
    protected String nombre;
    protected int vida;
    protected int vidaMax;
    protected int atk_fisico;
    protected int atk_magico;
    protected int armadura_magica;
    protected int armadura_fisica;
    protected int pm;
    
    //Métodos abstractos.
    public void ataqueFisico(Personaje enemigo){
     
        enemigo.setVida(enemigo.getVida() - (this.getAtk_fisico()*(100 - enemigo.getArmadura_fisica())/100));
    }
    
    //Getter and Setter.
    public ImageIcon getImagen() {
        return imagen;
    }

    public void setImagen(ImageIcon imagen) {
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getVidaMax() {
        return vidaMax;
    }

    public void setVidaMax(int vidaMax) {
        this.vidaMax = vidaMax;
    }

    public int getAtk_fisico() {
        return atk_fisico;
    }

    public void setAtk_fisico(int atk_fisico) {
        this.atk_fisico = atk_fisico;
    }

    public int getAtk_magico() {
        return atk_magico;
    }

    public void setAtk_magico(int atk_magico) {
        this.atk_magico = atk_magico;
    }

    public int getArmadura_magica() {
        return armadura_magica;
    }

    public void setArmadura_magica(int armadura_magica) {
        this.armadura_magica = armadura_magica;
    }

    public int getArmadura_fisica() {
        return armadura_fisica;
    }

    public void setArmadura_fisica(int armadura_fisica) {
        this.armadura_fisica = armadura_fisica;
    }

    public int getPm() {
        return pm;
    }

    public void setPm(int pm) {
        this.pm = pm;
    }
       
}
