package com.victor.juegorpg.Objetos;

import android.support.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.victor.juegorpg.Activities.Combate;
import com.victor.juegorpg.Activities.Creacion_Personaje;

public class Objetos {

    //Declaración de variables.
    private int cura=0;
    private int aumento_vidaMax=0;
    private int aumento_armadura_fisica=0;
    private int aumento_ataque_fisico=0;

    //Métodos constructores.
    public Objetos(){

    }

    //Método usarPocion el cual curará a nuestro personaje.
    public void usarPocion(){
        Creacion_Personaje.pj.setVida(Creacion_Personaje.pj.getVida() + cura);
        if(Creacion_Personaje.pj.getVida() > Creacion_Personaje.pj.getVidaMax()){
            Creacion_Personaje.pj.setVida(Creacion_Personaje.pj.getVidaMax());
        }
        Combate.texto_vida_pj.setText(Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax());
    }

    //Método ponerseArmadura el cual aumentará ciertas estadísticas a nuestro personaje.
    public void ponerseArmadura(){
        Creacion_Personaje.pj.setVidaMax(Creacion_Personaje.pj.getVidaMax() + aumento_vidaMax);
        Creacion_Personaje.pj.setArmadura_fisica(Creacion_Personaje.pj.getArmadura_fisica() + aumento_armadura_fisica);

    }

    //Método ponerseArmadura el cual aumentará el ataque a nuestro personaje.
    public void ponerseArma(){
        Creacion_Personaje.pj.setAtk_fisico(Creacion_Personaje.pj.getAtk_fisico() + aumento_ataque_fisico);
    }

    //Getters and Setters.
    public int getCura() {
        return cura;
    }
    public void setCura(int cura) {
        this.cura = cura;
    }

    public int getAumento_vidaMax() {
        return aumento_vidaMax;
    }

    public void setAumento_vidaMax(int aumento_vidaMax) {
        this.aumento_vidaMax = aumento_vidaMax;
    }

    public int getAumento_armadura_fisica() {
        return aumento_armadura_fisica;
    }

    public void setAumento_armadura_fisica(int aumento_armadura_fisica) {
        this.aumento_armadura_fisica = aumento_armadura_fisica;
    }

    public int getAumento_ataque_fisico() {
        return aumento_ataque_fisico;
    }

    public void setAumento_ataque_fisico(int aumento_ataque_fisico) {
        this.aumento_ataque_fisico = aumento_ataque_fisico;
    }
}
