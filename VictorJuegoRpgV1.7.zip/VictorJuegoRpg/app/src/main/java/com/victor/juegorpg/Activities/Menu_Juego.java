package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.victor.juegorpg.R;

public class Menu_Juego extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_juego);

        //Comando que quita la barra de arriba de la activity.
        getSupportActionBar().hide();

        //Cambio de Activity desde el "Menú_Juego" hasta la "Creación_Personaje".
        Button btn2 = (Button) findViewById(R.id.boton_jugador);
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent (Menu_Juego.this, Creacion_Personaje.class);
                startActivity(intent2);
            }
        });
    }
}
