package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.victor.juegorpg.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Comando que quita la barra de arriba de la activity.
        getSupportActionBar().hide();

        //Cambio de activity, desde la activity principal a la segunda activity.
        Button btn = (Button) findViewById(R.id.boton_comenzar_main);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this, Menu_Juego.class);
                startActivity(intent);
            }
        });

    }

}
