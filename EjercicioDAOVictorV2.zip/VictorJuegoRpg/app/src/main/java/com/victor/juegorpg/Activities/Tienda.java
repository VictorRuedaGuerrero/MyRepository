package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.victor.juegorpg.Objetos.Objetos;
import com.victor.juegorpg.R;

/**
 * Clase de la Activity de la tienda la cual nos mostrará la tienda del juego tras ganar un combate.
 * @author Víctor Rueda Guerrero.
 * @version 1.8
 */
public class Tienda extends AppCompatActivity implements View.OnClickListener {

    final FirebaseDatabase database = FirebaseDatabase.getInstance();

    //Declaración de objetos.
    public TextView texto_oro;
    public Button boton_compar_pocion_menor, boton_comprar_armadura, boton_comprar_espada;
    public Objetos cota_malla, espada;
    public Toast toast_pocion, toast_armadura, toast_espada;
    Intent i;

    //Declaración de variables.
    static int cantidad_pocion = 0, cantidad_armadura = 0;

    /**
     * Método que genera la Activity "Tienda".
     * @param savedInstanceState Guarda la información de la Activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tienda);

        //Comando que quita la barra de arriba de la activity.
        getSupportActionBar().hide();

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_oro = (TextView) findViewById(R.id.texto_oro);
        boton_compar_pocion_menor = (Button) findViewById(R.id.boton_comprar_pocion_menor);
        boton_comprar_armadura = (Button) findViewById(R.id.boton_comprar_armadura);
        boton_comprar_espada = (Button) findViewById(R.id.boton_comprar_espada);

        //Muestra el oro en el elemento TextView "texto_oro"
        texto_oro.setText("Oro: " + Combate.oro);

        Query crear_armadura = database.getReference("objetos").child("1").child("cota_malla");
        crear_armadura.addListenerForSingleValueEvent(new ValueEventListener() {

            /**
             * Método para pasar los datos de la armadura de la base de datos de FireBase al programa.
             * @param dataSnapshot Parámetro de tipo DataSnapshot que contiene los datos de la basede datos, según la ubicación indicada.
             */
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                cota_malla = dataSnapshot.getValue(Objetos.class);
            }

            /**
             * Método que muestra un Error, si este se produce, o lo que queramos en su lugar.
             * @param databaseError
             */
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Query crear_arma = database.getReference("objetos").child("2").child("espada");
        crear_arma.addListenerForSingleValueEvent(new ValueEventListener() {

            /**
             * Método para pasar los datos de la espada de la base de datos de FireBase al programa.
             * @param dataSnapshot Parámetro de tipo DataSnapshot que contiene los datos de la base de datos, según la ubicación indicada.
             */
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                espada = dataSnapshot.getValue(Objetos.class);
            }

            /**
             * Método que muestra un Error, si este se produce, o lo que queramos en su lugar.
             * @param databaseError
             */
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    /**
     * Método desde el que controlamos las acciones de los botones de la tienda.
     * @param v Parámetro de tipo View necesario para relacionar el método con los botones.
     */
    @Override
    public void onClick(View v) {

        int valor_objeto;

        switch(v.getId()){

            case R.id.boton_comprar_pocion_menor:
                valor_objeto = 50;
                if(Combate.oro < valor_objeto){
                    valor_objeto = 0;
                    boton_compar_pocion_menor.setEnabled(false);
                    toast_pocion = Toast.makeText(getApplicationContext(), "No tienes suficiente Oro", Toast.LENGTH_SHORT);
                    toast_pocion.show();
                }
                restaOro(valor_objeto);
                cantidad_pocion++;
            break;

            case R.id.boton_comprar_armadura:
                valor_objeto = 100;
                if(Combate.oro < valor_objeto){
                    valor_objeto = 0;
                    boton_comprar_armadura.setEnabled(false);
                    toast_armadura = Toast.makeText(getApplicationContext(), "No tienes suficiente Oro", Toast.LENGTH_SHORT);
                    toast_armadura.show();
                }
                restaOro(valor_objeto);
                cantidad_armadura++;
                cota_malla.ponerseArmadura();
                break;

            case R.id.boton_comprar_espada:
                valor_objeto = 100;
                if(Combate.oro < valor_objeto){
                    valor_objeto = 0;
                    boton_comprar_espada.setEnabled(false);
                    toast_espada = Toast.makeText(getApplicationContext(), "No tienes suficiente Oro", Toast.LENGTH_SHORT);
                    toast_espada.show();
                }
                restaOro(valor_objeto);
                espada.ponerseArma();
                break;

            case R.id.boton_listo:
                i = new Intent (Tienda.this, Combate.class);
                startActivity(i);
            break;
        }

        if(Combate.oro <= 0){
            Combate.oro = 0;
        }
        texto_oro.setText("Oro: " + Combate.oro);

    }

    /**
     * Método que resta el oro según el valor del objeto, pasado por parámetros.
     * @param valor_objeto Parámetro de tipo int el cual le pasa al método el valor de los objetos para realizar la resta.
     */

    public void restaOro(int valor_objeto){
        
        Combate.oro -= valor_objeto;

    }

}
