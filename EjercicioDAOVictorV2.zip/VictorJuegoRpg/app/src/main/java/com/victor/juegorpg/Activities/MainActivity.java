package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.victor.juegorpg.R;

import java.util.Objects;

/**
 * Clase de la Activity principal la cual nos mostrará el inicio de la aplicación y nos permitirá pasar a la siguiente Activity
 * a través de un botón.
 * @author Víctor Rueda Guerrero.
 * @version 1.8
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Método que genera la "Main Activity".
     * @param savedInstanceState Guarda la información de la Activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Comando que quita la barra de arriba de la activity.
        Objects.requireNonNull(getSupportActionBar()).hide();

        //Cambio de activity, desde "MainActivity" a "Menu_Juego".
        Button btn = (Button) findViewById(R.id.boton_comenzar_main);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this, Menu_Juego.class);
                startActivity(intent);
            }
        });

    }

}
