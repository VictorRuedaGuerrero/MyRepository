package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.victor.juegorpg.Clases.Asesino;
import com.victor.juegorpg.Clases.Guerrero;
import com.victor.juegorpg.Clases.Mago;
import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.Objetos.Objetos;
import com.victor.juegorpg.R;

import java.util.Objects;

/**
 * Clase de la Activity del combate la cual nos mostrará la Activity en la que comenzaremos a jugar, combatiendo contra un enemigo con nuestro personaje.
 * @author Víctor Rueda Guerrero.
 * @version 1.8
 */
public class Combate extends AppCompatActivity implements View.OnClickListener{

    //Declaración y creación dela base de datos de FireBase, "database", para poder implementarla al programa.
    final FirebaseDatabase database = FirebaseDatabase.getInstance();

    //Declaración de objetos.
    public static TextView texto_nombre_pj, texto_vida_pj, texto_vida_e;
    public ImageView imagen_pj, imagen_e;
    public Button boton_atacar, boton_objetos, boton_tienda, boton_terminar;
    public static Button boton_pocion;
    public ScrollView scroll_objetos;
    public Toast toast_perdida, toast_ganada;
    public Intent i;
    public Personaje enemigo;
    public Objetos pocion;

    //Declaración de un objeto "Handler" y un objeto "Runnable" para el control de tiempos en las acciones.
    Handler handler = new Handler();
    Runnable runnable;

    //Declaración de variables.
    String vida_e;
    String vida_pj;
    static boolean turnos=true;
    static boolean terminar_task;
    static int oro = 0;
    String clases_enemigos;
    static boolean visibilidad = false;

    /**
     * Método que genera la Activity del combate.
     * @param savedInstanceState Guarda la información de la Activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combate);

        //Comando que quita la barra de arriba de la activity.
        Objects.requireNonNull(getSupportActionBar()).hide();

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_nombre_pj = (TextView) findViewById(R.id.texto_nombre_pj);
        texto_vida_pj = (TextView) findViewById(R.id.texto_vida_pj);
        imagen_pj = (ImageView) findViewById(R.id.imagen_pj);
        texto_vida_e = (TextView) findViewById(R.id.texto_vida_e);
        imagen_e = (ImageView) findViewById(R.id.imagen_e);
        boton_atacar = (Button) findViewById(R.id.boton_atacar);
        boton_objetos = (Button) findViewById(R.id.boton_objetos);
        boton_tienda = (Button) findViewById(R.id.boton_tienda);
        boton_terminar = (Button) findViewById(R.id.boton_terminar);
        boton_pocion = (Button) findViewById(R.id.boton_pocion);


        //Pasamos el nombre escrito en "Creacion_Personaje" a la TextView del personaje en "Combate".
        String nombre = getIntent().getStringExtra("nombre");
        texto_nombre_pj.setText(nombre);

        //Pasamos la vida del personaje, según la clase seleccionada, desde "Creacion_Personaje" a la TextView del personaje en "Combate".
        //Condición que muestra al principio la vida del personaje en azul, si ha comprado armadura en la "Tienda".
        vida_pj = Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax();
        texto_vida_pj.setTextColor(Color.BLACK);
        texto_vida_pj.setText(vida_pj);
        if(Tienda.cantidad_armadura >= 1){
            texto_vida_pj.setTextColor(Color.BLUE);
        }

        //Pasamos la vida del enemigo, según la clase escogida aleatoriamente, a la TextView del personaje en "Combate".
        //NOTA: El enemigo es generado en el propio "Combate", para que pueda autogenerarse cuando haya más combates.
        //Esa asignación la realizamos con la llamada a los métodos "asignarNumClase()" y "asignarClaseEnemigo()".
        asignarNumClase();
        asignarClaseEnemigo();
        vida_e = enemigo.getVida() + " / " + enemigo.getVidaMax();
        texto_vida_e.setTextColor(Color.BLACK);
        texto_vida_e.setText(vida_e);

        //Llamada a los datos que necesitamos de nuestra base de datos y control para que no pueda usarse las pociones en el caso de que no se posea ninguna,
        // es decir, las pociones estén a 0.
        if(Tienda.cantidad_pocion > 0){
            Query crear_pocion = database.getReference("objetos").child("0").child("pocion");
            crear_pocion.addListenerForSingleValueEvent(new ValueEventListener() {
                /**
                 * Método para pasar los datos de la poción de la base de datos de FireBase al programa.
                 * @param dataSnapshot Parámetro de tipo DataSnapshot que contiene los datos de la base de datos, según la ubicación indicada.
                 */
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    pocion = dataSnapshot.getValue(Objetos.class);
                }

                /**
                 * Método que muestra un Error, si este se produce, o lo que queramos en su lugar.
                 * @param databaseError
                 */
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }

        terminar_task = false;

        //Asignamos la imagen del personaje al ImageView correspondiente según su clase.
        switch (Creacion_Personaje.pj.getClass().getSimpleName()){
            case "Guerrero":
                imagen_pj.setImageResource(R.drawable.guerrero);
                break;
            case "Asesino":
                imagen_pj.setImageResource(R.drawable.asesino);
                break;
            case "Mago":
                imagen_pj.setImageResource(R.drawable.mago);
                break;
            default:
                imagen_pj.setImageResource(R.drawable.ic_launcher_foreground);
                break;
        }


        //Asignamos la imagen del enemigo al ImageView correspondiente su clase.
        switch (enemigo.getClass().getSimpleName()){
            case "Guerrero":
                imagen_e.setImageResource(R.drawable.guerrero);
                break;
            case "Asesino":
                imagen_e.setImageResource(R.drawable.asesino);
                break;
            case "Mago":
                imagen_e.setImageResource(R.drawable.mago);
                break;
            default:
                imagen_e.setImageResource(R.drawable.ic_launcher_foreground);
                break;
        }
    }

    /**
     * Método que sirve para asignar aleatoriamente una clase del juego a un enemigo,
     * escogiendo un String de cada clase según el número que toque aleatoriamente.
     */
    public void asignarNumClase(){

        int numero = (int)(Math.random()*3)+1;

        switch(numero){
            case 1:
                clases_enemigos = "Guerrero";
                break;
            case 2:
                clases_enemigos = "Asesino";
                break;
            case 3:
                clases_enemigos = "Mago";
                break;
        }

    }

    /**
     * Método para asignar la clase al enemigo según el número obtenido en el método "asignarNumClase()".
     */
    public void asignarClaseEnemigo(){

        switch (clases_enemigos){
            case "Guerrero":
                enemigo = new Guerrero();
                break;

            case "Asesino":
                enemigo = new Asesino();
                break;

            case "Mago":
                enemigo = new Mago();
                break;

            default:
                enemigo = new Guerrero();
                break;
        }

    }

    /**
     * Método para desactivar botones.
     */
    public void desactivarBoton(){
        boton_atacar.setEnabled(false);
        boton_objetos.setEnabled(false);
    }

    /**
     * Método para activar botones.
     */
    public void activarBoton(){
        boton_atacar.setEnabled(true);
        boton_objetos.setEnabled(true);
    }

    /**
     * Método para volver los botones invisibles.
     */
    public void botonInvisible(){
        boton_atacar.setVisibility(View.INVISIBLE);
        boton_objetos.setVisibility(View.INVISIBLE);
    }

    /**
     * //Método desde el que controlamos las acciones de los botones del combate.
     * @param v Parámetro de tipo View necesario para relacionar el método con los botones.
     */
    @Override
    public void onClick(View v) {

        Task ataque = new Task();
        final Task ataqueEnemigo = new Task();

        //Implementación de un Runnable que nos permitirá darle un tiempo al programa para que nos permita
        //hacer de forma correcta la parada entre ataque y otra acción distinta, como curarnos.
        runnable = new Runnable(){
            @Override
            public void run() {
                ataqueEnemigo.execute();
                texto_vida_pj.setTextColor(Color.BLACK);
            }
        };

        switch (v.getId()){

            case R.id.boton_atacar:
                desactivarBoton();
                ataque.execute();
                ataqueEnemigo.execute();
                boton_pocion.setVisibility(View.INVISIBLE);
                break;

            case R.id.boton_objetos:
                visibilidad = cambiarvisible(visibilidad);
                if(visibilidad == true){
                    boton_pocion.setVisibility(View.VISIBLE);
                }else{
                    boton_pocion.setVisibility(View.INVISIBLE);
                }
                boton_pocion.setText("poción curativa x" + Tienda.cantidad_pocion);
                break;

            case R.id.boton_pocion:
                boton_pocion.setVisibility(View.INVISIBLE);
                if(Tienda.cantidad_pocion > 0 && Creacion_Personaje.pj.getVida() < Creacion_Personaje.pj.getVidaMax()){
                    pocion.usarPocion();
                    Tienda.cantidad_pocion--;
                    turnos=false;
                    handler.postDelayed(runnable,1000);
                    texto_vida_pj.setTextColor(Color.GREEN);
                    desactivarBoton();
                }
                break;

            case R.id.boton_tienda:
                i = new Intent(Combate.this, Tienda.class);
                startActivity(i);
                finish();
                break;

            case R.id.boton_terminar:
                i = new Intent(Combate.this, Menu_Juego.class);
                startActivity(i);
                finish();
                break;
        }

    }

    /**
     * //Método que utilizaremos para que al pulsar en el "botón objetos", nos permita tanto mostrar el "botón de poción" como quitarlo.
     * @param visible Parámetro de tipo boolean necesario para el control de la visibilidad del "botón objetos".
     * @return
     */

    public boolean cambiarvisible (boolean visible){
        if(visible == true){
            visible = false;
        }else if(visible == false){
            visible = true;
        }
        return visible;
    }

    /**
     * Clase Asynctask que controla los hilos para realizar el ataque de manera correcta, tanto el del enemigo como el del personaje.
     */
    class Task extends AsyncTask<Void,Integer,Void> {

        //Declaración de variables.
        boolean colores = true;

        /**
         * Método constructor por defecto de la clase AsyncTask.
         */
        public Task() {
        }

        /**
         * En el método "doInBackground" realizaremos ambos ataques controlados por un "boolean turnos", en el hilo principal, en el que
         * si está en TRUE se llevará a cabo el ataque del personaje y si está en FALSE se realizará el del enemigo.
         * También controlaremos el cambio de colores en la vida según el ataque realizado.
         * @param voids Parámetro de tipo void definido desde la clase Asynctask, enviado a los demás métodos.
         * @return No devuelve nada el método.
         */
        @Override
        protected Void doInBackground(Void... voids) {

            int vidaQueDisminuyeDe10en10 = -1;

            if (turnos == true) {
                int vidaFinalDelEnemigo = enemigo.getVida() - (Creacion_Personaje.pj.getAtk_fisico() * (100 - enemigo.getArmadura_fisica()) / 100);

                vidaQueDisminuyeDe10en10 = enemigo.getVida();

                //Mientras que la vida real del enemigo sea mayor que la que tendrá al final del combate la disminuimos y llamamos a Sleep para publicar
                // el valor momentáneo de la vida en la GUI (hilo principal).
                while (enemigo.getVida() > vidaFinalDelEnemigo && terminar_task == false) {
                    vidaQueDisminuyeDe10en10 = vidaQueDisminuyeDe10en10 - 10;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {}
                    enemigo.setVida(vidaQueDisminuyeDe10en10);
                    publishProgress(vidaQueDisminuyeDe10en10);

                    if (enemigo.getVida() <= 0) {
                        terminar_task = true;
                        break;
                    }
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {}

                turnos = false;

            } else {
                int vidaFinalDelPersonaje = Creacion_Personaje.pj.getVida() - (enemigo.getAtk_fisico() * (100 - Creacion_Personaje.pj.getArmadura_fisica()) / 100);

                vidaQueDisminuyeDe10en10 = Creacion_Personaje.pj.getVida();

                //Mientras que la vida real del personaje sea mayor que la que tendrá al final del combate la disminuimos y llamamos a Sleep para publicar
                // el valor momentáneo de la vida en la GUI (hilo principal).
                while (Creacion_Personaje.pj.getVida() > vidaFinalDelPersonaje && terminar_task == false) {
                    vidaQueDisminuyeDe10en10 = vidaQueDisminuyeDe10en10 - 10;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {}

                    Creacion_Personaje.pj.setVida(vidaQueDisminuyeDe10en10);
                    publishProgress(vidaQueDisminuyeDe10en10);

                    if (Creacion_Personaje.pj.getVida() <= 0) {
                        terminar_task = true;
                        break;
                    }
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {}

                turnos = true;
                colores = false;
                publishProgress(vidaQueDisminuyeDe10en10);
            }

            return null;
        }

        /**
         * Método "onProgressUpdate" en el que actualizamos la vida del personaje o del enemigo, de forma correcta en segundo plano, según quién haya atacado.
         * Además, hacemos una llamada al método "terminar" para que suceda una cosa si ganamos u otra si perdemos.
         * @param values Parámetro de tipo Integer definido desde la clase Asynctask, enviado a los demás métodos.
         */

        @Override
        protected void onProgressUpdate(Integer... values) {
            if (colores) {
                if (turnos == true) {
                    texto_vida_e.setTextColor(Color.RED);
                    texto_vida_pj.setTextColor(Color.BLACK);
                    texto_vida_e.setText(enemigo.getVida() + " / " + enemigo.getVidaMax());
                } else {
                    texto_vida_pj.setTextColor(Color.RED);
                    texto_vida_e.setTextColor(Color.BLACK);
                    texto_vida_pj.setText(Creacion_Personaje.pj.getVida() + " / " + Creacion_Personaje.pj.getVidaMax());
                }

            }else{
                if(Creacion_Personaje.pj.getVida() > 0) {
                    texto_vida_pj.setTextColor(Color.BLACK);
                }

                terminar();
            }

        }

        /**
         * Método "onPostExecute" en el que sé activan los botones del jugador (atacar y objetos) una vez vuelva a ser su turno.
         * @param aVoid Parámetro de tipo Integer definido desde la clase Asynctask, enviado a los demás métodos.
         */
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (turnos == true) {
                activarBoton();
            }
        }

        /**
         * Método "terminar" que sirve para realizar dos acciones diferentes, según si perdemos o ganamos, en el combate.
         */
        public void terminar() {
            //Condición para controlar que si ganamos, matando al enemigo,
            // aparecerá un mensaje de victoria con el oro obtenido y el botón para ir a la tienda.
            if (enemigo.getVida() <= 0) {
                oro = oro + 100;
                toast_ganada = Toast.makeText(getApplicationContext(), "VICTORIA!!, HAS GANADO: " + oro + " Oros.", Toast.LENGTH_LONG);
                toast_ganada.show();
                botonInvisible();
                boton_tienda.setVisibility(View.VISIBLE);
            }

            //Condición para controlar que si perdemos, matándonos el enemigo,
            //aparecerá un mensaje de derrota y un botón que nos devolverá al menú del juego("Menu_Juego").
            if (Creacion_Personaje.pj.getVida() <= 0) {
                toast_perdida = Toast.makeText(getApplicationContext(), "GAME OVER", Toast.LENGTH_LONG);
                toast_perdida.show();
                botonInvisible();
                boton_tienda.setVisibility(View.INVISIBLE);
                boton_terminar.setVisibility(View.VISIBLE);
            }
        }
    }
}






