package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.victor.juegorpg.R;

import java.util.Objects;

/**
 * Clase de la Activity del Menú del juego la cual nos mostrará la segunda pantalla y nos permitirá pasar a la siguiente Activity.
 * a través de un botón.
 * @author Víctor Rueda Guerrero.
 * @version 1.8
 */
public class Menu_Juego extends AppCompatActivity {

    /**
     * Método que genera la Activity "Menu_Juego"
     * @param savedInstanceState Guarda la información de la Activity.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_juego);

        //Comando que quita la barra de arriba de la activity.
        Objects.requireNonNull(getSupportActionBar()).hide();

        //Cambio de Activity desde el "Menú_Juego" hasta la "Creación_Personaje".
        Button btn2 = (Button) findViewById(R.id.boton_jugador);
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent (Menu_Juego.this, Creacion_Personaje.class);
                startActivity(intent2);
            }
        });
    }
}
