package com.victor.juegorpg.Clases;

/**
 * Clase Mago de los tipos de clase a escoger en el juego.
 */
public class Mago extends Personaje{

    /**
     * Método constructor por defecto.
     */
    public Mago(){
        this.vida = 500;
        this.vidaMax=this.vida;
        this.atk_fisico = 80;
        this.atk_magico = 100;
        this.armadura_fisica = 50;
        this.atk_magico = 0;
        this.pm = 100;
    }

    /**
     * Método constructor por parámetros.
     * @param vida Parámetro de tipo int que pasa la vida del mago.
     * @param atk_fisico Parámetro de tipo int que pasa el ataque físico del mago.
     * @param atk_magico Parámetro de tipo int que pasa el ataque mágico del mago.
     * @param armadura_fisica Parámetro de tipo int que pasa la armadura física del mago.
     * @param armadura_magica Parámetro de tipo int que pasa la armadura mágica del mago.
     * @param pm Parámetro de tipo int que pasa el "maná" del mago para lanzar habilidades.
     */
    public Mago(int vida, int atk_fisico, int atk_magico, int armadura_fisica, int armadura_magica, int pm) {
        this.vida = vida;
        this.vidaMax=vida;
        this.atk_fisico = atk_fisico;
        this.atk_magico = atk_magico;
        this.armadura_fisica = armadura_fisica;
        this.armadura_magica = armadura_magica;
        this.pm = pm;

    }
}
