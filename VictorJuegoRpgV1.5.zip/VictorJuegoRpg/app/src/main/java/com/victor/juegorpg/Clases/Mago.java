package com.victor.juegorpg.Clases;

public class Mago extends Personaje{

    //Métodos constructores.
    public Mago(){
        this.vida = 500;
        this.vidaMax=this.vida;
        this.atk_fisico = 80;
        this.atk_magico = 100;
        this.armadura_fisica = 50;
        this.atk_magico = 0;
        this.pm = 100;
    }

    public Mago(int vida, int atk_fisico, int atk_magico, int armadura_fisica, int armadura_magica, int pm) {
        this.vida = vida;
        this.vidaMax=vida;
        this.atk_fisico = atk_fisico;
        this.atk_magico = atk_magico;
        this.armadura_fisica = armadura_fisica;
        this.armadura_magica = armadura_magica;
        this.pm = pm;

    }
}
