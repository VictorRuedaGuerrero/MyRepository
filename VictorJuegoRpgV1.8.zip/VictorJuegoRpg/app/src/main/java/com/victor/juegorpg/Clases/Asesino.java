package com.victor.juegorpg.Clases;

/**
 * Clase Asesino de los tipos de clase a escoger en el juego.
 */
public class Asesino extends Personaje{

    /**
     * Método Constructor por defecto.
     */
    public Asesino(){
        this.vida = 600;
        this.vidaMax=this.vida;
        this.atk_fisico = 300;
        this.atk_magico = 0;
        this.armadura_fisica = 50;
        this.armadura_magica = 0;
        this.pm = 0;
    }

    /**
     * Método constructor por parámetros.
     * @param vida Parámetro de tipo int que pasa la vida del asesino.
     * @param atk_fisico Parámetro de tipo int que pasa el ataque físico del asesino.
     * @param atk_magico Parámetro de tipo int que pasa el ataque mágico del asesino.
     * @param armadura_fisica Parámetro de tipo int que pasa la armadura física del asesino.
     * @param armadura_magica Parámetro de tipo int que pasa la armadura mágica del asesino.
     * @param pm Parámetro de tipo int que pasa el "maná" del asesino para lanzar habilidades.
     */
    public Asesino(int vida, int atk_fisico, int atk_magico, int armadura_fisica, int armadura_magica, int pm) {
        this.vida = vida;
        this.vidaMax=vida;
        this.atk_fisico = atk_fisico;
        this.atk_magico = atk_magico;
        this.armadura_fisica = armadura_fisica;
        this.armadura_magica = armadura_magica;
        this.pm = pm;
    }
}
