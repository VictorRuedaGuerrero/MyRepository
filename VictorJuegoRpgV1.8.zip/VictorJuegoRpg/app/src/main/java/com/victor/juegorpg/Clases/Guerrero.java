package com.victor.juegorpg.Clases;

import android.media.Image;

/**
 * Clase Guerrero de los tipos de clase a escoger en el juego.
 */
public class Guerrero extends Personaje{

    /**
     * Método constructor por defecto.
     */
    public Guerrero(){
        this.vida = 800;
        this.vidaMax=this.vida;
        this.atk_fisico = 150;
        this.atk_magico = 0;
        this.armadura_fisica = 20;
        this.armadura_magica = 0;
        this.pm = 0;
    }

    /**
     * Método constructor por parámetros.
     * @param vida Parámetro de tipo int que pasa la vida del guerrero.
     * @param atk_fisico Parámetro de tipo int que pasa el ataque físico del guerrero.
     * @param atk_magico Parámetro de tipo int que pasa el ataque mágico del guerrero.
     * @param armadura_fisica Parámetro de tipo int que pasa la armadura física del guerrero.
     * @param armadura_magica Parámetro de tipo int que pasa la armadura mágica del guerrero.
     * @param pm Parámetro de tipo int que pasa el "maná" del guerrero para lanzar habilidades.
     */
    public Guerrero(int vida, int atk_fisico, int atk_magico, int armadura_fisica, int armadura_magica, int pm) {
        this.vida = vida;
        this.vidaMax=vida;
        this.atk_fisico = atk_fisico;
        this.atk_magico = atk_magico;
        this.armadura_fisica = armadura_fisica;
        this.armadura_magica = armadura_magica;
        this.pm = pm;
    }

}
