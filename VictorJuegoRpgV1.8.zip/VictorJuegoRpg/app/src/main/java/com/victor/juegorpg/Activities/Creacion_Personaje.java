package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.victor.juegorpg.Clases.Asesino;
import com.victor.juegorpg.Clases.Guerrero;
import com.victor.juegorpg.Clases.Mago;
import com.victor.juegorpg.Clases.Personaje;
import com.victor.juegorpg.R;

/**
 * Clase de la Activity para la creación del personaje la cual nos mostrará las opciones para crear nuestros personaje y el botón para comenzar a jugar.
 * @author Víctor Rueda Guerrero.
 * @version 1.8
 */
public class Creacion_Personaje extends AppCompatActivity {

    //Declaración de objetos.
    private Spinner spinner1;
    private EditText seleccion_nombre;
    private Bundle bundle_pj = new Bundle();
    private Bundle bundle_e = new Bundle();
    public static Personaje pj;
    Intent i;

    /**
     * Método que genera la Activity "Creacion_Personaje"
     * @param savedInstanceState Guarda la información de la Activity.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creacion_personaje);

        //Comando que quita la barra de arriba de la activity.
        getSupportActionBar().hide();

        //Relación entre los elementos de la activity y la parte lógica del programa.
        seleccion_nombre = findViewById(R.id.seleccion_nombre);
        spinner1 = (Spinner)findViewById(R.id.spinner);

        //Creación y asignación de los valores que indican el tipo de clases del juego a escoguer por el jugador al elemento Spinner.
        String [] opciones = {"Guerrero", "Asesino", "Mago"};

        ArrayAdapter <String> adapter = new ArrayAdapter <String>(this, R.layout.spinner_item, opciones );
        spinner1.setAdapter(adapter);

    }

    /**
     * Método que crea la clase de juego elegida y le pasa a la Activity del Combate, la siguiente Activity, el nombre seleccionado y la clase.
     * Además, nos envía a la siguiente Activity.
     * @param view Parámetro necesario para pasar de Activity.
     */
    public void crear(View view){
        i = new Intent(this, Combate.class);
        i.putExtra("nombre", seleccion_nombre.getText().toString());

        String clases = spinner1.getSelectedItem().toString();

        switch (clases){
            case "Guerrero":
                pj = new Guerrero();
                break;

            case "Asesino":
                pj = new Asesino();
                break;

            case "Mago":
                pj = new Mago();
                break;

            default:
                pj = new Guerrero();
                break;
        }
        startActivity(i);

    }
}
