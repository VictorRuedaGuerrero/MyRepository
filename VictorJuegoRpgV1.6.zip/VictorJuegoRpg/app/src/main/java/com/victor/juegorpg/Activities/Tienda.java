package com.victor.juegorpg.Activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.victor.juegorpg.Objetos.Objetos;
import com.victor.juegorpg.R;

public class Tienda extends AppCompatActivity implements View.OnClickListener {

    final FirebaseDatabase database = FirebaseDatabase.getInstance();

    //Declaración de objetos.
    public TextView texto_oro;
    public Button boton_compar_pocion_menor, boton_comprar_armadura, boton_comprar_espada;
    public Objetos cota_malla, espada;
    Intent i;

    //Declaración de variables.
    static int cantidad_pocion = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tienda);

        //Relación entre los elementos de la activity y la parte lógica del programa.
        texto_oro = (TextView) findViewById(R.id.texto_oro);
        boton_compar_pocion_menor = (Button) findViewById(R.id.boton_comprar_pocion_menor);
        boton_comprar_armadura = (Button) findViewById(R.id.boton_comprar_armadura);
        boton_comprar_espada = (Button) findViewById(R.id.boton_comprar_espada);

        //Muestra el oro en el elemento TextView "texto_oro"
        texto_oro.setText("Oro: " + Combate.oro);

        Query crear_armadura = database.getReference("objetos").child("1").child("cota_malla");
        crear_armadura.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                cota_malla = dataSnapshot.getValue(Objetos.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Query crear_arma = database.getReference("objetos").child("2").child("espada");
        crear_arma.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                espada = dataSnapshot.getValue(Objetos.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    //Método OnClick desde el que controlamos las acciones de los botones.
    @Override
    public void onClick(View v) {

        int valor_objeto;

        switch(v.getId()){

            case R.id.boton_comprar_pocion_menor:
                valor_objeto = 50;
                restaOro(valor_objeto);
                cantidad_pocion++;

            break;

            case R.id.boton_comprar_armadura:
                valor_objeto = 300;
                restaOro(valor_objeto);
                cota_malla.ponerseArmadura();
                break;

            case R.id.boton_comprar_espada:
                valor_objeto = 50;
                restaOro(valor_objeto);
                espada.ponerseArma();

            case R.id.boton_listo:
                i = new Intent (Tienda.this, Combate.class);
                startActivity(i);
            break;
        }

        texto_oro.setText("Oro: " + Combate.oro);

    }

    /*Método que resta el oro según el valor del objeto, pasado por parámetros. Además, controla si tienes menos cantidad
    que lo que vale el objeto, no te deja comprar más ese objeto.*/
    public void restaOro(int valor_objeto){

        Combate.oro -= valor_objeto;

        if(Combate.oro < 50){
            Combate.oro = 0;
            boton_compar_pocion_menor.setEnabled(false);
        }

        if(Combate.oro < 50){
            Combate.oro = 0;
            boton_comprar_armadura.setEnabled(false);
        }

        if(Combate.oro < 50){
            Combate.oro = 0;
            boton_comprar_espada.setEnabled(false);
        }


    }



}
